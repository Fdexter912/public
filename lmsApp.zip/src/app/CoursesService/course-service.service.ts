import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {
  constructor(private http: HttpClient) {}
  private apiUrl = "https://localhost:44329/api/Courses";

  addCourse(courseData: any): Observable<any> {
    const addCourseUrl = `${this.apiUrl}/AddCourses`;
    return this.http.post("https://localhost:44329/api/Courses/AddCourses", courseData);
  }

  getCourses(): Observable<any> {
    return this.http.get(this.apiUrl + '/GetAllCourses');
  }

  updateCourse(updatedCourseData: any, id: number): Observable <any>
  {
    const updateCourseUrl = "https://localhost:44329/api/Courses/UpdateCourses/"+id;
    return this.http.put(updateCourseUrl, updatedCourseData);
  }

  deleteCourse(id: number)
  {
    return this.http.delete<void>("https://localhost:44329/api/Courses/DeleteCourses/"+id);
  }
  


  courseAdded = new EventEmitter<any>();
  courseUpdated = new EventEmitter<any>();
  courseDeleted = new EventEmitter<any>();



}
