import { Component, OnInit } from '@angular/core';
import { CourseServiceService } from 'src/app/CoursesService/course-service.service';
@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent {
  courses: any;
  constructor(private CourseServiceService : CourseServiceService){}
  addCourse(cname: string): void {
    const CourseData= {
      courseName: cname
    };

    this.CourseServiceService.addCourse(CourseData.courseName).subscribe((response: any) => {
      console.log('Student added successfully:', response);
      // Emit an event to notify other components
      this.CourseServiceService.courseAdded.emit(response);
      // You can also refresh the student list by calling fetchStudents() here if needed.
    });
  } 


}
