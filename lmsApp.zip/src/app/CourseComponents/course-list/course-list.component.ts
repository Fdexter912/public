import { Component } from '@angular/core';
import { CourseServiceService } from 'src/app/CoursesService/course-service.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent {
  courses: any;
  constructor(private CourseServiceService : CourseServiceService){}
  ngOnInit(): void {
    this.CourseServiceService.getCourses().subscribe((data: any) => {
      this.courses = data;
      console.log(this.courses);
    });
  }

}
