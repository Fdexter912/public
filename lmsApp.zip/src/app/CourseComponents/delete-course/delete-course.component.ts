import { Component, OnInit } from '@angular/core';
import { CourseServiceService } from 'src/app/CoursesService/course-service.service';

@Component({
  selector: 'app-delete-course',
  templateUrl: './delete-course.component.html',
  styleUrls: ['./delete-course.component.css']
})
export class DeleteCourseComponent {
  course_ID: any = 0;
  constructor(private CourseServiceService : CourseServiceService){}
  deleteCourse(std: string)
  {
    const CourseID = parseInt(std);
    this.CourseServiceService.deleteCourse(CourseID).subscribe(response=> {
      this.CourseServiceService.courseDeleted.emit(response);
    })
  }

}
