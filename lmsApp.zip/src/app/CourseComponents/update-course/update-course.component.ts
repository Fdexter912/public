import { Component, OnInit } from '@angular/core';
import { CourseServiceService } from 'src/app/CoursesService/course-service.service';
@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent {
  constructor(private CourseServiceService : CourseServiceService){}
  updateCourse(id: string, cname: string)
  {
    const updatedCourseData = {
      CourseID: parseInt(id),
      CourseName: cname
    };
    this.CourseServiceService.updateCourse(updatedCourseData, updatedCourseData.CourseID).subscribe((response: any) => {
      console.log('Student updated successfully:', response);
      // Emit an event to notify other components
      this.CourseServiceService.courseUpdated.emit(response);
      // You can also refresh the student list by calling fetchStudents() here if needed.
    });
    

  }
}
