import { Component, OnInit } from '@angular/core';
import { AddStdntService } from 'src/app/StudentServices/add-stdnt.service';
@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit{
  stdnts: any ={};
  constructor(private AddStdntsService : AddStdntService){}
  ngOnInit(): void {
    // You can call this method when the component is initialized.
    this.fetchStudents();
  }
  fetchStudents(): void {
    this.AddStdntsService.getStdnts().subscribe((data: any) => {
      this.stdnts = data;
      console.log(this.stdnts);
    });
  }

  updateStudents(id: string, fname: string, lname: string, age: string, cid: string)
  {
    const updatedStudentData = {
      Student_ID: parseInt(id),
      FirstName: fname,
      LastName: lname,
      Age: parseInt(age),
      CourseID: parseInt(cid)
    };
    this.AddStdntsService.updateStudents(updatedStudentData, updatedStudentData.Student_ID).subscribe((response: any) => {
      console.log('Student updated successfully:', response);
      // Emit an event to notify other components
      this.AddStdntsService.studentUpdated.emit(response);
      // You can also refresh the student list by calling fetchStudents() here if needed.
    });
    

  }

}
