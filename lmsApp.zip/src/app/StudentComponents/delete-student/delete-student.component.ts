import { Component  } from '@angular/core';
import { AddStdntService } from 'src/app/StudentServices/add-stdnt.service';

@Component({
  selector: 'app-delete-student',
  templateUrl: './delete-student.component.html',
  styleUrls: ['./delete-student.component.css']
})
export class DeleteStudentComponent {
  studentID: any = 0;
  constructor(private AddStdntsService : AddStdntService){}
  deleteStudent(std: string)
  {
    const Student_ID = parseInt(std);
    this.AddStdntsService.deleteStudent(Student_ID).subscribe(response=> {
      // this.AddStdntsService.studentDeleted.emit(response);
    })
  }

 

}

