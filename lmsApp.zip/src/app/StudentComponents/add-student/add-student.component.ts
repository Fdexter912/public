import { Component, OnInit } from '@angular/core';
import { AddStdntService } from 'src/app/StudentServices/add-stdnt.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit{
  stdnts: any;
  constructor(private AddStdntsService : AddStdntService){}
  ngOnInit(): void {
    // You can call this method when the component is initialized.
    this.fetchStudents();
  }
 
  addStudents(fname: string, lname: string, age: string, cid: string): void {
    const studentData = {
      // You can get student data from form fields or other sources
      // Example:
      firstName: fname,
      lastName: lname,
      age: parseInt(age),
      courseId: parseInt(cid)
    };

    this.AddStdntsService.addStudents(studentData).subscribe((response: any) => {
      console.log('Student added successfully:', response);
      // Emit an event to notify other components
      this.AddStdntsService.studentAdded.emit(response);
      // You can also refresh the student list by calling fetchStudents() here if needed.
    });
  } 

  fetchStudents(): void {
    this.AddStdntsService.getStdnts().subscribe((data: any) => {
      this.stdnts = data;
      console.log(this.stdnts);
    });
  }

  

  
  


}
