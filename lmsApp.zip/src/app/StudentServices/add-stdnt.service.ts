import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddStdntService {
  constructor(private http: HttpClient) {}
  private apiUrl = "https://localhost:44329/api/Student";
  addStudents(studentData: any): Observable<any> {
    const addStudentUrl = `${this.apiUrl}/AddStudent`;
    return this.http.post(addStudentUrl, studentData);
  }

  getStdnts(): Observable<any> {
    return this.http.get(this.apiUrl + '/GetAllStudents');
  }

  updateStudents(updatedStudentData: any, id: number): Observable <any>
  {
    const updateStudentUrl = "https://localhost:44329/api/Student/UpdateStudent/"+id;
    return this.http.put(updateStudentUrl, updatedStudentData);
  }

  deleteStudent(id: number)
  {
    return this.http.delete<void>("https://localhost:44329/api/Student/DeleteStudent/"+id);
  }
  studentAdded = new EventEmitter<any>();
  studentUpdated = new EventEmitter<any>();
  studentDeleted = new EventEmitter<any>();




  

}
